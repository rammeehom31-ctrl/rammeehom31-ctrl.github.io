# Personal Portfolio Website - นายราเชน มีหอม (67011213251)
> **3D Artist & Creative Media Specialist**  
> สาขาวิชาสื่อนฤมิต (แขนงมัลติมีเดียและเกม) คณะวิทยาการสารสนเทศ มหาวิทยาลัยมหาสารคาม

---

## 📌 ภาพรวมโครงงาน (Project Overview)
เว็บไซต์พอร์ตโฟลิโอส่วนบุคคล (Personal Portfolio Multi-Page Website) พัฒนาขึ้นตามข้อกำหนดรายวิชา โดยเป็นเว็บไซต์แบบ **หลายหน้าเว็บเพจแยกจากกัน (Multi-Page Architecture)** ไม่อนุญาตให้ใช้แบบหน้าเดียว (Landing Page) พร้อมโครงสร้าง **ส่วนหัวนำทาง (Navigation Bar) และส่วนท้าย (Footer) ที่ตรงกัน 100% ทุกหน้าเว็บเพจ** จัดทำด้วยแนวคิด **AI Vibe Coding** ผสานการตรวจสอบความถูกต้องโดยมนุษย์ (Human-in-the-Loop)

---

## 🗂️ โครงสร้างไฟล์และหน้าเว็บเพจ (Pages & Directory Structure)

```
D:\Portfolio\
├── index.html                  # 1. หน้าแรก (Home): ข้อมูลแนะนำตัว, รูปถ่ายตนเอง, สรุปทักษะ และผลงานเด่น
├── education.html              # 2. ข้อมูลการศึกษา (Education): ไทม์ไลน์ 4 ระดับ (ม.ปลาย ศิลป์-ภาษาจีน โครงการ EP รร.สตรีศึกษาร้อยเอ็ด)
├── portfolio.html              # 3. แฟ้มสะสมผลงาน (Portfolio): แสดงผลงานจริง 3D Sculpting, Game Assets, Lighting และ Concept Art พร้อม Filter & Lightbox
├── activity.html               # 4. กิจกรรมและการอบรม (Activity): เจาะลึกโครงการค่ายพัฒนาทักษะ 3D Animation & Game : THACCA OFOS ระดับประเทศ
├── contact.html                # 5. ข้อมูลติดต่อ (Contact): ช่องทางติดต่อจริง, แผนที่ มมส. และแบบฟอร์มส่งข้อความ
├── AI_Use_Declaration.md       # เอกสารแบบแจ้งการใช้ AI ฉบับ Markdown
├── AI_Use_Declaration.pdf      # เอกสารแบบแจ้งการใช้ AI ฉบับ PDF ทางการ (สำหรับส่งอาจารย์ผู้สอน)
├── README.md                   # คู่มือโครงงานและการนำขึ้นระบบ (Deployment Guide)
└── assets/
    ├── css/
    │   └── style.css           # Glassmorphism Styling, ธีมสี Purple Cyber, Scrollbar, Lightbox
    ├── js/
    │   └── main.js             # Theme Toggle, Mobile Menu, Filter Tabs, Lightbox Modal, Form Feedback
    └── images/
        ├── profile.jpg         # รูปถ่ายจริงของ นายราเชน มีหอม
        ├── education/          # ภาพสถานศึกษา 4 แห่ง
        ├── portfolio/          # ภาพผลงาน 3D Sculpting, Art, Game Assets, Concept Art (18 ภาพ)
        └── activity/           # ภาพกิจกรรมและค่ายอบรม THACCA OFOS 3D (12 ภาพ)
```

---

## 🎨 จุดเด่นทางเทคโนโลยีและการออกแบบ (Key Features)
1. **Multi-Page Web Architecture:** แยกหน้า HTML ชัดเจน 5 หน้า มีการเชื่อมโยงเมนูนำทางที่ตรวจจับหน้าปัจจุบัน (`active state`) อัตโนมัติ
2. **Unified Navigation & Footer:** ส่วนหัวและส่วนท้ายของทุกหน้ามีความสอดคล้องตรงกัน 100%
3. **Dark / Light Theme Switcher:** สลับธีมมืดและสว่างได้ในคลิกเดียว พร้อมจดจำค่าลงใน `localStorage`
4. **Interactive Category Filter Tabs:** ในหน้า `portfolio.html` สามารถกรองชิ้นงานได้ตามประเภท (3D Sculpting, Game Assets, 3D Art & Lighting, Concept Art, Web UI/UX)
5. **Interactive Image Lightbox Modal:** คลิกดูภาพขนาดใหญ่พร้อมคำอธิบายและแท็กซอฟต์แวร์ รองรับการปิดด้วยปุ่ม Esc หรือคลิกพื้นหลัง
6. **Responsive Design:** แสดงผลสวยงามบนทุกขนาดหน้าจอ (Mobile, Tablet, Desktop)
7. **Simulated Contact Form:** แบบฟอร์มติดต่อที่ตอบสนองแบบ Interactive ทันทีที่ส่งข้อมูล

---

## 🚀 คู่มือการนำขึ้นระบบและการส่งงาน (Step-by-Step Deployment & Submission)

### ขั้นตอนที่ 1: การอัปโหลดซอร์สโค้ดขึ้น GitHub

#### วิธีที่ 1: ผ่านเว็บไซต์ GitHub (ง่ายที่สุด ไม่ต้องใช้คำสั่ง)
1. เข้าไปที่ [GitHub.com](https://github.com) แล้วเข้าสู่ระบบ
2. คลิกปุ่ม **New** (สร้าง Repository ใหม่)
3. ตั้งชื่อ Repository เช่น `Rachen-Meehom-Portfolio`
4. เลือกเป็น **Public** แล้วคลิก **Create repository**
5. ในหน้า Repository คลิกที่ลิงก์ **uploading an existing file**
6. ลากไฟล์และโฟลเดอร์ทั้งหมดจากโฟลเดอร์ `D:\Portfolio` (รวมโฟลเดอร์ `assets` และไฟล์ `.html` ทั้งหมด) มาวางในเบราว์เซอร์
7. พิมพ์ Commit message เช่น `Initial commit: Multi-page Portfolio website` แล้วคลิก **Commit changes**

#### วิธีที่ 2: ผ่านโปรแกรม GitHub Desktop (แนะนำ)
1. เปิดโปรแกรม GitHub Desktop
2. ไปที่เมนู `File` -> `Add Local Repository...`
3. เลือกโฟลเดอร์ `D:\Portfolio`
4. หากยังไม่ได้เป็น Git ให้กด `create a repository`
5. กดปุ่ม **Publish repository** เพื่อนำขึ้น GitHub บัญชีของคุณ

---

### ขั้นตอนที่ 2: การนำเว็บไซต์ขึ้นระบบออนไลน์ (Live Deployment)

#### วิธีที่ 1: Deploy ผ่าน Netlify Drop (เสร็จไวภายใน 10 วินาที โดยไม่ต้องต่อ Git)
1. เข้าไปที่ [app.netlify.com/drop](https://app.netlify.com/drop)
2. เข้าสู่ระบบด้วย GitHub หรืออีเมล
3. ลากโฟลเดอร์ `D:\Portfolio` ทั้งโฟลเดอร์มาวางลงในกรอบสี่เหลี่ยมบนหน้าเว็บ Netlify Drop
4. Netlify จะทำการ Deploy เว็บไซต์ให้ทันที และสร้าง Live URL เช่น `https://rachen-meehom-portfolio.netlify.app`
5. คุณสามารถเปลี่ยนชื่อโดเมนได้ที่ `Site configuration` -> `Change site name`

#### วิธีที่ 2: Deploy ผ่าน Vercel (เชื่อมต่อจาก GitHub)
1. เข้าไปที่ [vercel.com](https://vercel.com) แล้ว Login ด้วย GitHub
2. คลิก **Add New...** -> **Project**
3. เลือก Repository `Rachen-Meehom-Portfolio` ที่เพิ่งอัปโหลด
4. กดปุ่ม **Deploy** โดยไม่ต้องตั้งค่าเพิ่มเติม (เนื่องจากเป็น Static HTML)
5. จะได้รับ Live URL ใช้งานได้ทันที เช่น `https://rachen-meehom-portfolio.vercel.app`

---

### ขั้นตอนที่ 3: การเตรียมเอกสารส่งงาน

สิ่งที่ต้องส่งให้อาจารย์ผู้สอนตามข้อกำหนด:
1. **URL เว็บไซต์จริง (Live Website URL):** (เช่น URL จาก Netlify หรือ Vercel)
2. **URL แหล่งเก็บโค้ด (GitHub Repository URL):** (เช่น `https://github.com/username/Rachen-Meehom-Portfolio`)
3. **ไฟล์แบบแจ้งการใช้ AI (AI Use Declaration):**  
   - ไฟล์เอกสาร PDF พร้อมพิมพ์หรือแนบส่ง: `D:\Portfolio\AI_Use_Declaration.pdf`
   - ไฟล์ Markdown ต้นฉบับ: `D:\Portfolio\AI_Use_Declaration.md`

---

## 👤 ข้อมูลผู้จัดทำ
* **นายราเชน มีหอม (Mr. Rachen Meehom)**
* **รหัสนิสิต:** 67011213251
* **สาขาวิชา:** สื่อนฤมิต (แขนงมัลติมีเดียและเกม)
* **คณะ:** วิทยาการสารสนเทศ มหาวิทยาลัยมหาสารคาม
* **อีเมล:** rameehom31@gmail.com
* **Facebook:** [ram.meehom](https://www.facebook.com/ram.meehom)
* **Instagram:** [@rt_w_eety](https://www.instagram.com/rt_w_eety/)
