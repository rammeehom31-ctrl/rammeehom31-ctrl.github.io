/**
 * Rachen Meehom Portfolio - Main JavaScript
 * Handles Theme Toggle, Navigation, Filters, and Lightbox Modal
 */

document.addEventListener('DOMContentLoaded', () => {
    // -------------------------------------------------------------
    // 1. Theme Management (Dark / Light Mode)
    // -------------------------------------------------------------
    const htmlElement = document.documentElement;
    const themeToggleBtn = document.getElementById('theme-toggle');
    const themeToggleMobileBtn = document.getElementById('theme-toggle-mobile');

    // Default to dark mode if not explicitly set to light
    if (localStorage.theme === 'light') {
        htmlElement.classList.remove('dark');
    } else {
        htmlElement.classList.add('dark');
        localStorage.theme = 'dark';
    }

    function toggleTheme() {
        if (htmlElement.classList.contains('dark')) {
            htmlElement.classList.remove('dark');
            localStorage.theme = 'light';
        } else {
            htmlElement.classList.add('dark');
            localStorage.theme = 'dark';
        }
    }

    themeToggleBtn?.addEventListener('click', toggleTheme);
    themeToggleMobileBtn?.addEventListener('click', toggleTheme);

    // -------------------------------------------------------------
    // 2. Mobile Menu Toggle
    // -------------------------------------------------------------
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    mobileMenuBtn?.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
        const icon = mobileMenuBtn.querySelector('i');
        if (mobileMenu.classList.contains('hidden')) {
            icon.className = 'fas fa-bars text-xl';
        } else {
            icon.className = 'fas fa-times text-xl';
        }
    });

    // -------------------------------------------------------------
    // 3. Highlight Current Page in Navigation
    // -------------------------------------------------------------
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPath || (currentPath === '' && href === 'index.html')) {
            link.classList.add('active');
            if (link.classList.contains('mobile-nav-link')) {
                link.classList.add('bg-[#C99A3D]/20', 'text-[#C99A3D]', 'border-l-2', 'border-[#C99A3D]');
            }
        }
    });

    // -------------------------------------------------------------
    // 4. Portfolio Filter Tabs (For portfolio.html)
    // -------------------------------------------------------------
    const filterButtons = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => {
                b.classList.remove('bg-gradient-to-r', 'from-[#ECC875]', 'to-[#C99A3D]', 'text-[#0B0A09]', 'font-bold', 'border-[#F0D9A0]', 'shadow-md');
                b.classList.add('bg-slate-200/80', 'dark:bg-[#181512]', 'text-slate-700', 'dark:text-[#FBF9F5]', 'border-slate-300', 'dark:border-[#C99A3D]/30');
            });
            btn.classList.remove('bg-slate-200/80', 'dark:bg-[#181512]', 'text-slate-700', 'dark:text-[#FBF9F5]', 'border-slate-300', 'dark:border-[#C99A3D]/30');
            btn.classList.add('bg-gradient-to-r', 'from-[#ECC875]', 'to-[#C99A3D]', 'text-[#0B0A09]', 'font-bold', 'border-[#F0D9A0]', 'shadow-md');

            const filterValue = btn.getAttribute('data-filter');

            portfolioItems.forEach(item => {
                if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                    item.style.display = 'block';
                    item.classList.add('fade-in');
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // -------------------------------------------------------------
    // 5. Image Lightbox Modal
    // -------------------------------------------------------------
    const lightboxModal = document.getElementById('lightboxModal');
    const lightboxImg = document.getElementById('lightboxImg');
    const lightboxTitle = document.getElementById('lightboxTitle');
    const lightboxDesc = document.getElementById('lightboxDesc');
    const lightboxTag = document.getElementById('lightboxTag');
    const closeLightboxBtn = document.getElementById('closeLightbox');

    window.openLightbox = function(imageSrc, title, desc, tag) {
        if (!lightboxModal) return;
        lightboxImg.src = imageSrc;
        lightboxTitle.innerText = title || '';
        lightboxDesc.innerText = desc || '';
        if (lightboxTag) lightboxTag.innerText = tag || '';
        lightboxModal.classList.add('show');
        document.body.style.overflow = 'hidden';
    };

    function closeLightbox() {
        if (!lightboxModal) return;
        lightboxModal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }

    closeLightboxBtn?.addEventListener('click', closeLightbox);
    lightboxModal?.addEventListener('click', (e) => {
        if (e.target === lightboxModal) closeLightbox();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeLightbox();
    });

    // -------------------------------------------------------------
    // 6. Contact Form Simulation (For contact.html)
    // -------------------------------------------------------------
    const contactForm = document.getElementById('contactForm');
    const formAlert = document.getElementById('formSuccessAlert');

    contactForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const oldContent = submitBtn.innerHTML;

        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> กำลังส่งข้อมูล...';
        submitBtn.disabled = true;

        setTimeout(() => {
            contactForm.reset();
            submitBtn.innerHTML = oldContent;
            submitBtn.disabled = false;

            if (formAlert) {
                formAlert.classList.remove('hidden');
                setTimeout(() => {
                    formAlert.classList.add('hidden');
                }, 6000);
            }
        }, 1000);
    });

    // -------------------------------------------------------------
    // 7. Back to Top Button
    // -------------------------------------------------------------
    const backToTopBtn = document.getElementById('backToTopBtn');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 400) {
            backToTopBtn?.classList.remove('opacity-0', 'invisible');
            backToTopBtn?.classList.add('opacity-100', 'visible');
        } else {
            backToTopBtn?.classList.add('opacity-0', 'invisible');
            backToTopBtn?.classList.remove('opacity-100', 'visible');
        }
    });

    backToTopBtn?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
