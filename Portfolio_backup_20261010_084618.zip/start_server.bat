@echo off
title Rachen Meehom Portfolio - Local HTTP Server
cd /d "%~dp0"
echo ================================================================
echo   Launching Rachen Meehom Portfolio HTTP Web Server...
echo ================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "server.ps1"
pause
