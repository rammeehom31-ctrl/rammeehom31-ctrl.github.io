# Rachen Meehom Portfolio - Standalone Local HTTP Server (PowerShell)

param(
    [int]$Port = 8080,
    [string]$Root = "D:\Portfolio"
)

# Test if port is available, if not find next available port
while ($true) {
    $tcp = Test-NetConnection -ComputerName localhost -Port $Port -InformationLevel Quiet -WarningAction SilentlyContinue
    if (-not $tcp) { break }
    $Port++
}

$listener = New-Object System.Net.HttpListener
$urlPrefix1 = "http://localhost:$Port/"
$urlPrefix2 = "http://127.0.0.1:$Port/"
$listener.Prefixes.Add($urlPrefix1)
$listener.Prefixes.Add($urlPrefix2)

$mimeMap = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".png"  = "image/png"
    ".gif"  = "image/gif"
    ".webp" = "image/webp"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".pdf"  = "application/pdf"
    ".woff" = "font/woff"
    ".woff2"= "font/woff2"
    ".ttf"  = "font/ttf"
    ".otf"  = "font/otf"
}

try {
    $listener.Start()
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  ✦ RACHEN MEEHOM PORTFOLIO - LOCAL HTTP WEB SERVER ✦" -ForegroundColor Yellow
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  Web Link:    $urlPrefix1" -ForegroundColor Green
    Write-Host "  Alternative: $urlPrefix2" -ForegroundColor Green
    Write-Host "  Root Folder: $Root" -ForegroundColor Gray
    Write-Host "  Status:      Running (Press Ctrl+C in this window to stop)" -ForegroundColor Yellow
    Write-Host "================================================================" -ForegroundColor Cyan

    # Launch browser automatically
    Start-Process $urlPrefix1

    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $request = $context.Request
            $response = $context.Response

            $path = $request.Url.LocalPath
            if ($path -eq "/" -or $path -eq "") {
                $path = "/index.html"
            }

            # Security check - prevent directory traversal
            $safePath = $path.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
            $fullPath = [System.IO.Path]::GetFullPath((Join-Path $Root $safePath))

            if (-not $fullPath.StartsWith([System.IO.Path]::GetFullPath($Root), [System.StringComparison]::OrdinalIgnoreCase)) {
                $response.StatusCode = 403
                $msg = [System.Text.Encoding]::UTF8.GetBytes("403 Forbidden")
                $response.OutputStream.Write($msg, 0, $msg.Length)
                $response.Close()
                continue
            }

            if (Test-Path $fullPath -PathType Leaf) {
                $ext = [System.IO.Path]::GetExtension($fullPath).ToLower()
                $mime = if ($mimeMap.ContainsKey($ext)) { $mimeMap[$ext] } else { "application/octet-stream" }
                $bytes = [System.IO.File]::ReadAllBytes($fullPath)

                $response.ContentType = $mime
                $response.ContentLength64 = $bytes.Length
                $response.Headers.Add("Access-Control-Allow-Origin", "*")
                $response.Headers.Add("Cache-Control", "no-cache")
                $response.StatusCode = 200
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                $response.OutputStream.Flush()
                Write-Host "[200 OK] $path" -ForegroundColor Green
            } else {
                $response.StatusCode = 404
                $response.ContentType = "text/html; charset=utf-8"
                $html404 = "<h1>404 Not Found</h1><p>The requested file $path was not found.</p>"
                $msg = [System.Text.Encoding]::UTF8.GetBytes($html404)
                $response.OutputStream.Write($msg, 0, $msg.Length)
                Write-Host "[404 Not Found] $path" -ForegroundColor Red
            }

            $response.Close()
        }
        catch [System.Net.HttpListenerException] {
            break
        }
        catch {
            Write-Warning "Request handling notice: $($_.Exception.Message)"
        }
    }
}
catch {
    Write-Error $_
}
finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
    $listener.Close()
    Write-Host "Server stopped." -ForegroundColor Gray
}
